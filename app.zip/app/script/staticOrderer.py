__author__ = 'Filippo'
import csv
with open("../data/artistsStaticData", 'w') as csvfile:
