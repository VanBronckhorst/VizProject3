
var staticTimelineColors = d3.scale.category20();

//staticTimelineColors = _.shuffle( staticTimelineColors );

var dynamicTimelineColorBlue = "#ABD9E9";

var dynamicTimelineColorRed = "#FEE0D2";

colorForGenre = {};

